﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace Rent_A_Car_Quattro.Models
{
    public class Poslovnica
    {
        [Key]
        public int ID { get; set; }
        public int broj_dostupnih_vozila { get; set; }
        [ForeignKey("Lokacija")]
        public int lokacija_fk { get; set; }
    }

}
   
