﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Rent_A_Car_Quattro.Models
{
    public class AktivneRezervacije
    {
        [Key]
        public int ID { get; set; }
        [ForeignKey("ApplicationUser")]
        public int korisnikId { get; set; }
        [ForeignKey("Rezervacija")]
        public int rezervacijaId { get; set; }
    }
}
