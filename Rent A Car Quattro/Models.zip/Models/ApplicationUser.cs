﻿using System;
namespace Rent_A_Car_Quattro.Models
{
	public class ApplicationUser
	{
		public ApplicationUser()
		{
		}
	}
}

