﻿using System.ComponentModel.DataAnnotations;

namespace Rent_A_Car_Quattro.Models
{
    public class Klijent
    {
        [Key]
        public int ID { get; set; }
        public  String? Ime { get; set; }
        public String? Prezime { get; set; }
        public String? Username { get; set; }    
        public String? Password { get; set; }
        public String? Email { get; set; }
        public DateTime DatumRodjenja { get; set; }
        public String? Jmbg {  get; set; }
       // public List<Rezervacija> AktivneRezervacije { get; set; }
    }
}