﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Rent_A_Car_Quattro.Models
{
    public class DostupnaVozila
    {
        [Key]
        public int ID { get; set; }
        [ForeignKey("Vozilo")]
        public int VoziloId { get; set; }
        [ForeignKey("Poslovnica")]
        public int PoslovnicaId { get; set; }
    }
}
