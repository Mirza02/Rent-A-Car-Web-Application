﻿using System.ComponentModel.DataAnnotations;

namespace Rent_A_Car_Quattro.Models
{
    public enum proba
    {
        proba1 = 1,
        proba2 = 2
    }
}
